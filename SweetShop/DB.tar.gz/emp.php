<?php include 'connection.php';

//$connect = mysql_connect("localhost","root","hotmailyaho");
//if($connect)
//{
//  mysql_query("use sweet_shop;",$connect);
  $insert = "insert into EMPLOYEE values (
    '',
    '".$_REQUEST["fname"]."',
    '".$_REQUEST["lname"]."',
    '".$_REQUEST["dob"]."',
    '".$_REQUEST["age"]."',
    '".$_REQUEST["sex"]."',
    '".$_REQUEST["fno"]."',
    '".$_REQUEST["street"]."',
    '".$_REQUEST["sector"]."',
    '".$_REQUEST["city"]."',
    '".$_REQUEST["dno"]."'
  );";
  
  mysql_query($insert);
  echo mysql_error();
 header("location:emp.html");
//}
//else
//{emp
